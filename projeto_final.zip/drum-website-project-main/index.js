// Detectando clique do mouse nos botões da bateria.

// Laço que percorre todos os botões da bateria.

// Adicionar um evento a cada botão para o evento de "click".
    
// Detectar o pressionamento de teclas no teclado.

// Função que toca o som correspondente a uma tecla (pesquisar sobre o case).

// Função que anima o botão que foi pressionado ou clicado.